//DAC.h

#include <stdint.h>


void DAC_Init(void);

void DAC_Out(uint16_t output);

