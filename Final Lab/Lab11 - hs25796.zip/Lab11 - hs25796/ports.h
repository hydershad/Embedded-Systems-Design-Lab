//port listings for input/outputs

/*
PE5 = U5TX
PE4 = U5RX
PD3 = Ain from IR reciever
PB3 connected to driver for stepper motor coil RED
PB2 connected to driver for stepper motor coil BLUE
PB1 connected to driver for stepper motor coil YELLOW
PB0 connected to driver for stepper motor coil ORANGE
PB4-5 left MOTOR  control
PD0-1, right MOTOR control
PB7, PWM
*/


