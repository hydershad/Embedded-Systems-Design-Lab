//motor.h

void brake(void);
void drive(void);
void reverse(void);
void motor_init(void);

